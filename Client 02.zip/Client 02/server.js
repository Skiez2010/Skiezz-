const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, // Set to true in production with HTTPS
        maxAge: 1000 * 60 * 60 * 24 * 7 // 7 days
    }
}));

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Load configuration from config.json
let data = {};
try {
    const configPath = path.join(__dirname, 'config.json');
    if (fs.existsSync(configPath)) {
        const configData = fs.readFileSync(configPath, 'utf8');
        const config = JSON.parse(configData);
        data = {
            profile: config.profile || {},
            projects: config.projects || [],
            skills: config.skills || [],
            social: config.social || {},
            theme: config.theme || {}
        };
        console.log('✅ Configuration chargée depuis config.json');
    } else {
        throw new Error('config.json non trouvé');
    }
} catch (error) {
    console.error('⚠️  Erreur lors du chargement de config.json:', error.message);
    // Use default data if config.json is not found
    data = {
        profile: {
            name: 'Portfolio',
            title: 'Bienvenue',
            email1: 'contact@example.com',
            email2: 'support@example.com',
            avatar: 'https://via.placeholder.com/150'
        },
        projects: [],
        skills: [],
        social: {},
        theme: {}
    };
}

// User credentials (in production, use a database)
const users = {
    'admin': bcrypt.hashSync('admin123', 10)
};

// Function to save configuration to file
function saveConfig() {
    try {
        const configPath = path.join(__dirname, 'config.json');
        const config = {
            profile: data.profile,
            projects: data.projects,
            skills: data.skills,
            social: data.social || {},
            theme: data.theme || {}
        };
        fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
        console.log('✅ Configuration sauvegardée');
    } catch (error) {
        console.error('❌ Erreur lors de la sauvegarde:', error);
    }
}

// Middleware to check authentication
const isAuthenticated = (req, res, next) => {
    if (req.session.userId) {
        next();
    } else {
        res.status(401).json({ message: 'Non autorisé' });
    }
};

// ============ AUTH ROUTES ============

app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Nom d\'utilisateur et mot de passe requis' });
    }

    if (!users[username]) {
        return res.status(401).json({ message: 'Identifiants incorrects' });
    }

    const isPasswordValid = bcrypt.compareSync(password, users[username]);

    if (!isPasswordValid) {
        return res.status(401).json({ message: 'Identifiants incorrects' });
    }

    req.session.userId = username;
    res.json({ 
        message: 'Connexion réussie',
        user: username 
    });
});

app.post('/api/auth/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).json({ message: 'Erreur lors de la déconnexion' });
        }
        res.json({ message: 'Déconnexion réussie' });
    });
});

app.get('/api/auth/status', (req, res) => {
    if (req.session.userId) {
        res.json({ 
            authenticated: true, 
            user: req.session.userId 
        });
    } else {
        res.json({ 
            authenticated: false 
        });
    }
});

app.post('/api/auth/change-password', isAuthenticated, (req, res) => {
    const { currentPassword, newPassword, confirmPassword } = req.body;

    if (!currentPassword || !newPassword || !confirmPassword) {
        return res.status(400).json({ message: 'Tous les champs sont requis' });
    }

    if (newPassword !== confirmPassword) {
        return res.status(400).json({ message: 'Les mots de passe ne correspondent pas' });
    }

    if (newPassword.length < 6) {
        return res.status(400).json({ message: 'Le mot de passe doit contenir au moins 6 caractères' });
    }

    const username = req.session.userId;
    const isPasswordValid = bcrypt.compareSync(currentPassword, users[username]);

    if (!isPasswordValid) {
        return res.status(401).json({ message: 'Mot de passe actuel incorrect' });
    }

    users[username] = bcrypt.hashSync(newPassword, 10);
    res.json({ message: 'Mot de passe changé avec succès' });
});

// ============ PROFILE ROUTES ============

app.get('/api/profile', (req, res) => {
    res.json(data.profile);
});

app.put('/api/profile', isAuthenticated, (req, res) => {
    const { name, title, email1, email2, avatar } = req.body;

    if (name) data.profile.name = name;
    if (title) data.profile.title = title;
    if (email1) data.profile.email1 = email1;
    if (email2) data.profile.email2 = email2;
    if (avatar) data.profile.avatar = avatar;

    // Save to config.json
    saveConfig();

    res.json({ 
        message: 'Profil mis à jour',
        profile: data.profile 
    });
});

// ============ PROJECTS ROUTES ============

app.get('/api/projects', (req, res) => {
    res.json(data.projects);
});

app.post('/api/projects', isAuthenticated, (req, res) => {
    const { name, role, logo, users, servers, date, site, support, invite } = req.body;

    if (!name || !role) {
        return res.status(400).json({ message: 'Nom et rôle requis' });
    }

    const newProject = {
        id: Date.now(),
        name,
        role,
        logo,
        users,
        servers,
        date,
        site,
        support,
        invite
    };

    data.projects.push(newProject);
    saveConfig();
    
    res.status(201).json({ 
        message: 'Projet créé',
        project: newProject 
    });
});

app.put('/api/projects/:id', isAuthenticated, (req, res) => {
    const projectId = parseInt(req.params.id);
    const project = data.projects.find(p => p.id === projectId);

    if (!project) {
        return res.status(404).json({ message: 'Projet non trouvé' });
    }

    const { name, role, logo, users, servers, date, site, support, invite } = req.body;

    if (name) project.name = name;
    if (role) project.role = role;
    if (logo) project.logo = logo;
    if (users) project.users = users;
    if (servers) project.servers = servers;
    if (date) project.date = date;
    if (site) project.site = site;
    if (support) project.support = support;
    if (invite) project.invite = invite;

    saveConfig();

    res.json({ 
        message: 'Projet mis à jour',
        project 
    });
});

app.delete('/api/projects/:id', isAuthenticated, (req, res) => {
    const projectId = parseInt(req.params.id);
    const index = data.projects.findIndex(p => p.id === projectId);

    if (index === -1) {
        return res.status(404).json({ message: 'Projet non trouvé' });
    }

    const deleted = data.projects.splice(index, 1);
    saveConfig();
    
    res.json({ 
        message: 'Projet supprimé',
        project: deleted[0] 
    });
});

// ============ SKILLS ROUTES ============

app.get('/api/skills', (req, res) => {
    res.json(data.skills);
});

app.post('/api/skills', isAuthenticated, (req, res) => {
    const { name, level } = req.body;

    if (!name || level === undefined) {
        return res.status(400).json({ message: 'Nom et niveau requis' });
    }

    const newSkill = {
        id: Date.now(),
        name,
        level: parseInt(level)
    };

    data.skills.push(newSkill);
    saveConfig();
    
    res.status(201).json({ 
        message: 'Compétence créée',
        skill: newSkill 
    });
});

app.put('/api/skills/:id', isAuthenticated, (req, res) => {
    const skillId = parseInt(req.params.id);
    const skill = data.skills.find(s => s.id === skillId);

    if (!skill) {
        return res.status(404).json({ message: 'Compétence non trouvée' });
    }

    const { name, level } = req.body;

    if (name) skill.name = name;
    if (level !== undefined) skill.level = parseInt(level);

    saveConfig();

    res.json({ 
        message: 'Compétence mise à jour',
        skill 
    });
});

app.delete('/api/skills/:id', isAuthenticated, (req, res) => {
    const skillId = parseInt(req.params.id);
    const index = data.skills.findIndex(s => s.id === skillId);

    if (index === -1) {
        return res.status(404).json({ message: 'Compétence non trouvée' });
    }

    const deleted = data.skills.splice(index, 1);
    saveConfig();
    
    res.json({ 
        message: 'Compétence supprimée',
        skill: deleted[0] 
    });
});

// ============ GENERAL ROUTES ============

app.get('/api/data', (req, res) => {
    res.json(data);
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Erreur serveur' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ message: 'Route non trouvée' });
});

// Start server
app.listen(PORT, () => {
    console.log(`Serveur démarré sur http://localhost:${PORT}`);
    console.log(`Portfolio: http://localhost:${PORT}/`);
    console.log(`Admin Panel: http://localhost:${PORT}/admin`);
});

module.exports = app;
