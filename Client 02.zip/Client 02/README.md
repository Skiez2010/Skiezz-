# Portfolio & Admin Panel - Server Node.js

Un portfolio moderne avec un panel admin intégré, construit avec Node.js, Express et Vue.

## 📋 Fonctionnalités

- **Portfolio public**: Affichage des projets et compétences
- **Panel admin complet**: Gestion des projets, compétences et profil
- **Authentification**: Système de connexion sécurisé
- **API REST**: Endpoints complets pour toutes les opérations
- **Design moderne**: Interface responsive et moderne
- **Stockage en mémoire**: Données persistantes pendant la session

## 🚀 Installation

### Prérequis
- Node.js (v14 ou supérieur)
- npm ou yarn

### Étapes d'installation

1. **Accédez au dossier du projet**
```bash
cd "c:\Users\remix\Documents\Client 02"
```

2. **Installez les dépendances**
```bash
npm install
```

3. **Démarrez le serveur**
```bash
npm start
```

Pour développement avec hot-reload:
```bash
npm run dev
```

## 📍 Accès

Une fois le serveur démarré:

- **Portfolio public**: http://localhost:5000/
- **Panel admin**: http://localhost:5000/admin
- **API Base**: http://localhost:5000/api

## 🔐 Authentification

Identifiants de test pour l'admin:
- **Nom d'utilisateur**: `admin`
- **Mot de passe**: `admin123`

## 📁 Structure du projet

```
├── server.js              # Serveur Express principal
├── package.json           # Dépendances du projet
├── .env                   # Configuration d'environnement
└── public/
    ├── index.html         # Page d'accueil du portfolio
    ├── admin.html         # Page du panel admin
    ├── style.css          # Styles du portfolio
    ├── admin-style.css    # Styles du panel admin
    ├── script.js          # Script du portfolio
    └── admin-script.js    # Script du panel admin
```

## 🔌 API Endpoints

### Authentification
- `POST /api/auth/login` - Connexion
- `POST /api/auth/logout` - Déconnexion
- `GET /api/auth/status` - Vérifier le statut

### Profil
- `GET /api/profile` - Récupérer le profil
- `PUT /api/profile` - Mettre à jour le profil

### Projets
- `GET /api/projects` - Lister les projets
- `POST /api/projects` - Créer un projet
- `PUT /api/projects/:id` - Mettre à jour un projet
- `DELETE /api/projects/:id` - Supprimer un projet

### Compétences
- `GET /api/skills` - Lister les compétences
- `POST /api/skills` - Créer une compétence
- `PUT /api/skills/:id` - Mettre à jour une compétence
- `DELETE /api/skills/:id` - Supprimer une compétence

## 🎨 Customisation

### Variables d'environnement (.env)
```
PORT=5000                    # Port du serveur
SESSION_SECRET=your-secret   # Clé secrète de session
NODE_ENV=development         # Environnement
```

### Configuration du serveur
Modifiez `server.js` pour:
- Changer les credentials d'authentification
- Modifier les données initiales
- Ajouter plus de routes API

## 📦 Technologies utilisées

- **Node.js**: Plateforme serveur
- **Express**: Framework web
- **bcryptjs**: Hachage des mots de passe
- **express-session**: Gestion des sessions
- **CORS**: Partage des ressources
- **Body-parser**: Parsing des requêtes

## 🔒 Sécurité

- Authentification basique avec sessions
- Mots de passe hachés avec bcryptjs
- CORS configuré
- Middleware d'authentification pour routes protégées

## 📝 Notes

- Les données sont stockées en mémoire et seront réinitialisées au redémarrage
- Pour la production, utilisez une base de données réelle
- Configurez `SESSION_SECRET` avec une valeur unique
- Activez HTTPS en production

## 🤝 Support

Pour toute question ou problème, vérifiez:
1. Les logs du serveur
2. Les erreurs dans la console du navigateur
3. L'état de la connexion API

## 📄 Licence

MIT
