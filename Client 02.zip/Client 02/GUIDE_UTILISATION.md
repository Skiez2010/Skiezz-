# 📝 GUIDE D'UTILISATION SIMPLE

## Pour changer TON PORTFOLIO

**C'est simple:** Tu dois juste éditer le fichier `config.json` et c'est tout! 🎉

---

## 📋 Comment faire?

### 1️⃣ Ouvre le fichier `config.json`

Ouvre le fichier `config.json` à la racine du projet avec un éditeur de texte (VS Code, Notepad++, etc.)

### 2️⃣ Modifie TES INFORMATIONS

```json
{
  "profile": {
    "name": "Ton Nom",                    ← Change ça
    "title": "Ton Titre",                 ← Change ça
    "description": "Ta description",      ← Change ça
    "avatar": "https://lien-photo.jpg",   ← Mets le lien de ta photo
    "email1": "ton-email@domaine.com",    ← Change ça
    "email2": "second-email@domaine.com", ← Change ça
    "discord": "https://discord.gg/..."   ← Change ça
  }
}
```

### 3️⃣ Ajoute TES PROJETS

```json
{
  "id": 1,
  "name": "Nom du Projet",          ← Change ça
  "role": "Ton rôle",               ← Change ça
  "description": "Description",     ← Change ça
  "logo": "https://logo.jpg",       ← Mets le lien du logo
  "users": "1K+",                   ← Mets le nombre d'utilisateurs
  "servers": "100",                 ← Mets le nombre de serveurs
  "date": "2025-01-15",             ← Mets la date
  "site": "https://site.com",       ← Lien du site
  "support": "https://discord.gg/", ← Lien support
  "invite": "https://...",          ← Lien d'invitation
  "tags": ["tag1", "tag2"]          ← Tags du projet
}
```

### 4️⃣ Ajoute TES COMPÉTENCES

```json
{
  "id": 1,
  "name": "Ma Compétence",    ← Change ça
  "level": 95,                ← Niveau de 0 à 100
  "category": "Backend"       ← Catégorie (Backend, Frontend, etc)
}
```

### 5️⃣ Ajoute TES RÉSEAUX SOCIAUX

```json
"social": {
  "twitter": "https://twitter.com/...",
  "github": "https://github.com/...",
  "linkedin": "https://linkedin.com/...",
  "youtube": "https://youtube.com/...",
  "instagram": "https://instagram.com/..."
}
```

### 6️⃣ Sauvegarde le fichier

Appuie sur `Ctrl+S` pour sauvegarder. C'est tout! 🎉

---

## 🚀 Accès à ton portfolio

Une fois que tu as modifié le `config.json`:

- **Portfolio public**: http://localhost:5000/
- **Panel admin**: http://localhost:5000/admin
  - Identifiant: `admin`
  - Mot de passe: `admin123`

---

## 🎨 Personnaliser les COULEURS

Si tu veux changer les couleurs:

```json
"theme": {
  "primaryColor": "#5865f2",      ← Couleur principale (bleu)
  "secondaryColor": "#4f46e5",    ← Couleur secondaire
  "accentColor": "#10b981",       ← Couleur accent (vert)
  "backgroundColor": "#0f172a",   ← Fond foncé
  "surfaceColor": "#1e293b",      ← Couleur de surface
  "textPrimary": "#f1f5f9",       ← Texte principal (blanc)
  "textSecondary": "#cbd5e1"      ← Texte secondaire (gris)
}
```

*Utilise des codes HEX de couleurs (#RRGGBB)*

---

## 📸 Où trouver des IMAGES?

Pour les avatars, logos, etc:
- **Unsplash**: https://unsplash.com
- **Pexels**: https://pexels.com
- **Discord CDN**: Pour les avatars Discord
- Ton serveur personnel

---

## ✅ EXEMPLE COMPLET

Voici un exemple complet avec des vraies données:

```json
{
  "profile": {
    "name": "Jean Dupont",
    "title": "Développeur Full Stack",
    "description": "Passionné par le code et l'innovation",
    "avatar": "https://unsplash.com/photos/photo.jpg",
    "email1": "jean@example.com",
    "email2": "contact@example.com",
    "discord": "https://discord.gg/abc123"
  },
  "projects": [
    {
      "id": 1,
      "name": "MonApp",
      "role": "Créateur Principal",
      "description": "Une application super cool",
      "logo": "https://example.com/logo.png",
      "users": "5K+",
      "servers": "200",
      "date": "2025-01-15",
      "site": "https://monapp.com",
      "support": "https://discord.gg/support",
      "invite": "https://monapp.com/invite",
      "tags": ["React", "Node.js", "MongoDB"]
    }
  ],
  "skills": [
    {
      "id": 1,
      "name": "React.js",
      "level": 95,
      "category": "Frontend"
    },
    {
      "id": 2,
      "name": "Node.js",
      "level": 90,
      "category": "Backend"
    }
  ]
}
```

---

## 🔧 Si quelque chose ne fonctionne pas

1. **Vérifie la syntaxe du JSON**: Utilise https://jsonlint.com/
2. **Redémarre le serveur**: `npm start`
3. **Vide le cache du navigateur**: Ctrl+Shift+Delete

---

## 💡 ASTUCES

- Tu peux ajouter autant de projets et compétences que tu veux
- Les données se sauvegardent automatiquement dans `config.json`
- Le panel admin permet aussi de modifier les données
- Les modifications via le panel sont automatiquement sauvegardées

---

**C'est aussi simple que ça!** 🎉

Modifie le `config.json`, le serveur fait le reste! ✨
