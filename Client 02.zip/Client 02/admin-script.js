// Admin Panel Script
class AdminPanel {
    constructor() {
        this.currentUser = null;
        this.projects = [];
        this.skills = [];
        this.settings = {
            name: '',
            title: '',
            email1: '',
            email2: '',
            avatar: ''
        };

        this.init();
    }

    init() {
        this.loadFromLocalStorage();
        this.setupEventListeners();
        this.loadInitialData();
    }

    setupEventListeners() {
        // Login
        document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('logoutBtn').addEventListener('click', () => this.handleLogout());

        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => this.switchSection(e));
        });

        // Projects
        document.getElementById('addProjectBtn').addEventListener('click', () => this.openProjectModal());
        document.getElementById('closeProjectModal').addEventListener('click', () => this.closeProjectModal());
        document.getElementById('cancelProjectBtn').addEventListener('click', () => this.closeProjectModal());
        document.getElementById('projectForm').addEventListener('submit', (e) => this.handleProjectSubmit(e));

        // Skills
        document.getElementById('addSkillBtn').addEventListener('click', () => this.openSkillModal());
        document.getElementById('closeSkillModal').addEventListener('click', () => this.closeSkillModal());
        document.getElementById('cancelSkillBtn').addEventListener('click', () => this.closeSkillModal());
        document.getElementById('skillForm').addEventListener('submit', (e) => this.handleSkillSubmit(e));
        document.getElementById('skillLevel').addEventListener('input', (e) => this.updateSkillLevelDisplay(e));

        // Settings
        document.getElementById('settingsForm').addEventListener('submit', (e) => this.handleSettingsSubmit(e));
        document.getElementById('changePasswordBtn').addEventListener('click', () => this.openPasswordModal());
        document.getElementById('closePasswordModal').addEventListener('click', () => this.closePasswordModal());
        document.getElementById('cancelPasswordBtn').addEventListener('click', () => this.closePasswordModal());
        document.getElementById('passwordForm').addEventListener('submit', (e) => this.handlePasswordSubmit(e));
        document.getElementById('clearDataBtn').addEventListener('click', () => this.clearData());

        // Sidebar toggle
        document.getElementById('toggleSidebar').addEventListener('click', () => this.toggleSidebar());

        // Skill level display
        document.getElementById('skillLevel').addEventListener('input', (e) => {
            document.getElementById('skillLevelDisplay').textContent = e.target.value + '%';
        });
    }

    handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Simple authentication (in production, use server-side auth)
        if ((username === 'admin' && password === 'admin123') ||
            (username === this.settings.name && password === 'password')) {
            this.currentUser = username;
            this.showAdminPanel();
            document.getElementById('currentUser').textContent = username;
            this.saveToLocalStorage();
        } else {
            alert('Identifiants incorrects!');
        }
    }

    handleLogout() {
        if (confirm('Êtes-vous sûr de vouloir vous déconnecter?')) {
            this.currentUser = null;
            document.getElementById('loginForm').reset();
            this.showLoginModal();
            this.saveToLocalStorage();
        }
    }

    showLoginModal() {
        document.getElementById('loginModal').classList.add('active');
        document.getElementById('adminPanel').classList.add('hidden');
    }

    showAdminPanel() {
        document.getElementById('loginModal').classList.remove('active');
        document.getElementById('adminPanel').classList.remove('hidden');
        this.switchSection(null, 'dashboard');
    }

    switchSection(e, sectionId = null) {
        if (e) {
            e.preventDefault();
            sectionId = e.currentTarget.dataset.section;
        }

        // Update active nav item
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        if (e) {
            e.currentTarget.classList.add('active');
        } else {
            document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');
        }

        // Update active section
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionId).classList.add('active');

        // Update header
        const titles = {
            'dashboard': 'Tableau de bord',
            'projects': 'Gestion des Projets',
            'skills': 'Gestion des Compétences',
            'settings': 'Paramètres'
        };
        document.querySelector('.admin-header h1').textContent = titles[sectionId];
    }

    loadInitialData() {
        this.addDefaultProjects();
        this.addDefaultSkills();
        this.renderProjects();
        this.renderSkills();
        this.loadSettings();
    }

    addDefaultProjects() {
        if (this.projects.length === 0) {
            this.projects = [
                {
                    id: 1,
                    name: 'Chell',
                    role: 'Cofondateur du bot français Chell',
                    logo: 'https://chell.fr/logo.png',
                    users: '43.3K+',
                    servers: '331',
                    date: '2025-10-15',
                    site: 'https://chell.fr/',
                    support: 'https://discord.gg/abDZXg74HS',
                    invite: 'https://discord.com/oauth2/authorize?client_id=1383154920231796736'
                },
                {
                    id: 2,
                    name: 'GLaDOS',
                    role: 'Coordinateur de Sécurité',
                    logo: 'https://aperture-sciences.com/logo.png',
                    users: '301.7K+',
                    servers: '9.1K+',
                    date: '2025-10-15',
                    site: 'http://aperture-sciences.com/',
                    support: 'https://discord.gg/BHuGx7UGaW',
                    invite: 'https://discord.com/oauth2/authorize?client_id=1098179232779223080'
                }
            ];
        }
    }

    addDefaultSkills() {
        if (this.skills.length === 0) {
            this.skills = [
                { id: 1, name: 'Discord & Modération', level: 100 },
                { id: 2, name: 'Pterodactyl', level: 35 },
                { id: 3, name: 'NodeJS', level: 35 },
                { id: 4, name: 'Anglais (Niveau B2)', level: 70 }
            ];
        }
    }

    openProjectModal(projectId = null) {
        const modal = document.getElementById('projectModal');
        const form = document.getElementById('projectForm');

        if (projectId) {
            const project = this.projects.find(p => p.id === projectId);
            if (project) {
                document.getElementById('projectName').value = project.name;
                document.getElementById('projectRole').value = project.role;
                document.getElementById('projectLogo').value = project.logo;
                document.getElementById('projectUsers').value = project.users;
                document.getElementById('projectServers').value = project.servers;
                document.getElementById('projectDate').value = project.date;
                document.getElementById('projectSite').value = project.site;
                document.getElementById('projectSupport').value = project.support;
                document.getElementById('projectInvite').value = project.invite;
                form.dataset.projectId = projectId;
            }
        } else {
            form.reset();
            delete form.dataset.projectId;
        }

        modal.classList.add('active');
    }

    closeProjectModal() {
        document.getElementById('projectModal').classList.remove('active');
    }

    handleProjectSubmit(e) {
        e.preventDefault();
        const projectId = e.target.dataset.projectId;

        const projectData = {
            name: document.getElementById('projectName').value,
            role: document.getElementById('projectRole').value,
            logo: document.getElementById('projectLogo').value,
            users: document.getElementById('projectUsers').value,
            servers: document.getElementById('projectServers').value,
            date: document.getElementById('projectDate').value,
            site: document.getElementById('projectSite').value,
            support: document.getElementById('projectSupport').value,
            invite: document.getElementById('projectInvite').value
        };

        if (projectId) {
            const project = this.projects.find(p => p.id == projectId);
            Object.assign(project, projectData);
        } else {
            projectData.id = Date.now();
            this.projects.push(projectData);
        }

        this.saveToLocalStorage();
        this.renderProjects();
        this.closeProjectModal();
        this.showNotification('Projet enregistré avec succès!');
    }

    deleteProject(projectId) {
        if (confirm('Êtes-vous sûr de vouloir supprimer ce projet?')) {
            this.projects = this.projects.filter(p => p.id !== projectId);
            this.saveToLocalStorage();
            this.renderProjects();
            this.showNotification('Projet supprimé!');
        }
    }

    renderProjects() {
        const container = document.getElementById('projectsList');
        container.innerHTML = this.projects.map(project => `
            <div class="item-card">
                <div class="item-info">
                    <h3>${project.name}</h3>
                    <p>${project.role}</p>
                </div>
                <div class="item-actions">
                    <button class="icon-btn" onclick="adminPanel.openProjectModal(${project.id})" title="Éditer">✏️</button>
                    <button class="icon-btn" onclick="adminPanel.deleteProject(${project.id})" title="Supprimer">🗑️</button>
                </div>
            </div>
        `).join('');

        document.getElementById('projectCount').textContent = this.projects.length;
    }

    openSkillModal(skillId = null) {
        const modal = document.getElementById('skillModal');
        const form = document.getElementById('skillForm');

        if (skillId) {
            const skill = this.skills.find(s => s.id === skillId);
            if (skill) {
                document.getElementById('skillName').value = skill.name;
                document.getElementById('skillLevel').value = skill.level;
                document.getElementById('skillLevelDisplay').textContent = skill.level + '%';
                form.dataset.skillId = skillId;
            }
        } else {
            form.reset();
            document.getElementById('skillLevel').value = 50;
            document.getElementById('skillLevelDisplay').textContent = '50%';
            delete form.dataset.skillId;
        }

        modal.classList.add('active');
    }

    closeSkillModal() {
        document.getElementById('skillModal').classList.remove('active');
    }

    handleSkillSubmit(e) {
        e.preventDefault();
        const skillId = e.target.dataset.skillId;

        const skillData = {
            name: document.getElementById('skillName').value,
            level: parseInt(document.getElementById('skillLevel').value)
        };

        if (skillId) {
            const skill = this.skills.find(s => s.id == skillId);
            Object.assign(skill, skillData);
        } else {
            skillData.id = Date.now();
            this.skills.push(skillData);
        }

        this.saveToLocalStorage();
        this.renderSkills();
        this.closeSkillModal();
        this.showNotification('Compétence enregistrée avec succès!');
    }

    deleteSkill(skillId) {
        if (confirm('Êtes-vous sûr de vouloir supprimer cette compétence?')) {
            this.skills = this.skills.filter(s => s.id !== skillId);
            this.saveToLocalStorage();
            this.renderSkills();
            this.showNotification('Compétence supprimée!');
        }
    }

    renderSkills() {
        const container = document.getElementById('skillsList');
        container.innerHTML = this.skills.map(skill => `
            <div class="item-card">
                <div class="item-info">
                    <h3>${skill.name}</h3>
                    <p>Niveau: ${skill.level}%</p>
                </div>
                <div class="item-actions">
                    <button class="icon-btn" onclick="adminPanel.openSkillModal(${skill.id})" title="Éditer">✏️</button>
                    <button class="icon-btn" onclick="adminPanel.deleteSkill(${skill.id})" title="Supprimer">🗑️</button>
                </div>
            </div>
        `).join('');

        document.getElementById('skillCount').textContent = this.skills.length;
    }

    updateSkillLevelDisplay(e) {
        document.getElementById('skillLevelDisplay').textContent = e.target.value + '%';
    }

    loadSettings() {
        document.getElementById('settingName').value = this.settings.name;
        document.getElementById('settingTitle').value = this.settings.title;
        document.getElementById('settingEmail1').value = this.settings.email1;
        document.getElementById('settingEmail2').value = this.settings.email2;
        document.getElementById('settingAvatar').value = this.settings.avatar;
    }

    handleSettingsSubmit(e) {
        e.preventDefault();

        this.settings.name = document.getElementById('settingName').value;
        this.settings.title = document.getElementById('settingTitle').value;
        this.settings.email1 = document.getElementById('settingEmail1').value;
        this.settings.email2 = document.getElementById('settingEmail2').value;
        this.settings.avatar = document.getElementById('settingAvatar').value;

        this.saveToLocalStorage();
        this.showNotification('Paramètres enregistrés avec succès!');
    }

    openPasswordModal() {
        document.getElementById('passwordModal').classList.add('active');
    }

    closePasswordModal() {
        document.getElementById('passwordModal').classList.remove('active');
        document.getElementById('passwordForm').reset();
    }

    handlePasswordSubmit(e) {
        e.preventDefault();

        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            alert('Les mots de passe ne correspondent pas!');
            return;
        }

        if (newPassword.length < 6) {
            alert('Le mot de passe doit contenir au moins 6 caractères!');
            return;
        }

        // In production, verify current password on server
        this.settings.password = newPassword;
        this.saveToLocalStorage();
        this.closePasswordModal();
        this.showNotification('Mot de passe modifié avec succès!');
    }

    clearData() {
        if (confirm('Êtes-vous sûr? Cette action supprimera tous les projets et compétences!')) {
            this.projects = [];
            this.skills = [];
            this.saveToLocalStorage();
            this.loadInitialData();
            this.showNotification('Données réinitialisées!');
        }
    }

    toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('open');
    }

    saveToLocalStorage() {
        localStorage.setItem('adminData', JSON.stringify({
            currentUser: this.currentUser,
            projects: this.projects,
            skills: this.skills,
            settings: this.settings
        }));
    }

    loadFromLocalStorage() {
        const data = localStorage.getItem('adminData');
        if (data) {
            const parsed = JSON.parse(data);
            this.currentUser = parsed.currentUser;
            this.projects = parsed.projects || [];
            this.skills = parsed.skills || [];
            this.settings = { ...this.settings, ...parsed.settings };
        }
    }

    showNotification(message) {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--accent-color);
            color: white;
            padding: 1rem 2rem;
            border-radius: 0.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            z-index: 2000;
            animation: slideIn 0.3s ease;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Initialize Admin Panel
const adminPanel = new AdminPanel();

// Check if user is logged in
if (adminPanel.currentUser) {
    adminPanel.showAdminPanel();
} else {
    adminPanel.showLoginModal();
}
