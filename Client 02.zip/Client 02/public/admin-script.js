// Admin Panel Script with API Integration
const API_BASE = 'http://localhost:5000/api';

class AdminPanel {
    constructor() {
        this.currentUser = null;
        this.projects = [];
        this.skills = [];
        this.profile = {};
        this.init();
    }

    async init() {
        this.setupEventListeners();
        this.checkAuthStatus();
    }

    setupEventListeners() {
        // Login
        document.getElementById('loginForm').addEventListener('submit', (e) => this.handleLogin(e));
        document.getElementById('logoutBtn').addEventListener('click', () => this.handleLogout());

        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => this.switchSection(e));
        });

        // Projects
        document.getElementById('addProjectBtn').addEventListener('click', () => this.openProjectModal());
        document.getElementById('closeProjectModal').addEventListener('click', () => this.closeProjectModal());
        document.getElementById('cancelProjectBtn').addEventListener('click', () => this.closeProjectModal());
        document.getElementById('projectForm').addEventListener('submit', (e) => this.handleProjectSubmit(e));

        // Skills
        document.getElementById('addSkillBtn').addEventListener('click', () => this.openSkillModal());
        document.getElementById('closeSkillModal').addEventListener('click', () => this.closeSkillModal());
        document.getElementById('cancelSkillBtn').addEventListener('click', () => this.closeSkillModal());
        document.getElementById('skillForm').addEventListener('submit', (e) => this.handleSkillSubmit(e));
        document.getElementById('skillLevel').addEventListener('input', (e) => this.updateSkillLevelDisplay(e));

        // Settings
        document.getElementById('settingsForm').addEventListener('submit', (e) => this.handleSettingsSubmit(e));
        document.getElementById('passwordForm').addEventListener('submit', (e) => this.handlePasswordSubmit(e));

        // Sidebar toggle
        document.getElementById('toggleSidebar').addEventListener('click', () => this.toggleSidebar());
    }

    async checkAuthStatus() {
        try {
            const response = await fetch(`${API_BASE}/auth/status`);
            const data = await response.json();
            
            if (data.authenticated) {
                this.currentUser = data.user;
                this.showAdminPanel();
                await this.loadAllData();
            } else {
                this.showLoginModal();
            }
        } catch (error) {
            console.error('Erreur lors de la vérification du statut:', error);
            this.showLoginModal();
        }
    }

    async handleLogin(e) {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        try {
            const response = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password }),
                credentials: 'include'
            });

            if (response.ok) {
                const data = await response.json();
                this.currentUser = data.user;
                document.getElementById('currentUser').textContent = username;
                document.getElementById('loginForm').reset();
                this.showAdminPanel();
                await this.loadAllData();
            } else {
                this.showNotification('Identifiants incorrects!', 'error');
            }
        } catch (error) {
            console.error('Erreur de connexion:', error);
            this.showNotification('Erreur de connexion', 'error');
        }
    }

    async handleLogout() {
        if (confirm('Êtes-vous sûr de vouloir vous déconnecter?')) {
            try {
                await fetch(`${API_BASE}/auth/logout`, {
                    method: 'POST',
                    credentials: 'include'
                });
                this.currentUser = null;
                this.showLoginModal();
            } catch (error) {
                console.error('Erreur de déconnexion:', error);
            }
        }
    }

    showLoginModal() {
        document.getElementById('loginModal').classList.add('active');
        document.getElementById('adminPanel').classList.add('hidden');
    }

    showAdminPanel() {
        document.getElementById('loginModal').classList.remove('active');
        document.getElementById('adminPanel').classList.remove('hidden');
        this.switchSection(null, 'dashboard');
    }

    switchSection(e, sectionId = null) {
        if (e) {
            e.preventDefault();
            sectionId = e.currentTarget.dataset.section;
        }

        // Update active nav item
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        if (e) {
            e.currentTarget.classList.add('active');
        } else {
            document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');
        }

        // Update active section
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionId).classList.add('active');

        // Update header
        const titles = {
            'dashboard': 'Tableau de bord',
            'projects': 'Gestion des Projets',
            'skills': 'Gestion des Compétences',
            'settings': 'Paramètres'
        };
        document.querySelector('.admin-header h1').textContent = titles[sectionId];
    }

    async loadAllData() {
        await this.loadProfile();
        await this.loadProjects();
        await this.loadSkills();
        this.loadSettings();
    }

    async loadProfile() {
        try {
            const response = await fetch(`${API_BASE}/profile`);
            this.profile = await response.json();
        } catch (error) {
            console.error('Erreur lors du chargement du profil:', error);
        }
    }

    async loadProjects() {
        try {
            const response = await fetch(`${API_BASE}/projects`);
            this.projects = await response.json();
            this.renderProjects();
        } catch (error) {
            console.error('Erreur lors du chargement des projets:', error);
        }
    }

    async loadSkills() {
        try {
            const response = await fetch(`${API_BASE}/skills`);
            this.skills = await response.json();
            this.renderSkills();
        } catch (error) {
            console.error('Erreur lors du chargement des compétences:', error);
        }
    }

    async openProjectModal(projectId = null) {
        const modal = document.getElementById('projectModal');
        const form = document.getElementById('projectForm');

        if (projectId) {
            const project = this.projects.find(p => p.id === projectId);
            if (project) {
                document.getElementById('projectName').value = project.name;
                document.getElementById('projectRole').value = project.role;
                document.getElementById('projectDescription').value = project.description || '';
                document.getElementById('projectLogo').value = project.logo;
                document.getElementById('projectUsers').value = project.users || '';
                document.getElementById('projectServers').value = project.servers || '';
                document.getElementById('projectDate').value = project.date;
                document.getElementById('projectSite').value = project.site || '';
                document.getElementById('projectSupport').value = project.support || '';
                document.getElementById('projectInvite').value = project.invite || '';
                document.getElementById('projectGithub').value = project.github || '';
                document.getElementById('projectPortfolio').value = project.portfolio || '';
                document.getElementById('projectVideos').value = JSON.stringify(project.videos || []);
                document.getElementById('projectTags').value = (project.tags || []).join(', ');
                form.dataset.projectId = projectId;
            }
        } else {
            form.reset();
            document.getElementById('projectVideos').value = '[]';
            delete form.dataset.projectId;
        }

        modal.classList.add('active');
    }

    closeProjectModal() {
        document.getElementById('projectModal').classList.remove('active');
    }

    async handleProjectSubmit(e) {
        e.preventDefault();
        const projectId = e.target.dataset.projectId;

        try {
            // Parse videos JSON
            let videos = [];
            const videosInput = document.getElementById('projectVideos').value.trim();
            if (videosInput && videosInput !== '[]') {
                videos = JSON.parse(videosInput);
            }

            // Parse tags
            const tagsInput = document.getElementById('projectTags').value;
            const tags = tagsInput ? tagsInput.split(',').map(t => t.trim()) : [];

            const projectData = {
                name: document.getElementById('projectName').value,
                role: document.getElementById('projectRole').value,
                description: document.getElementById('projectDescription').value,
                logo: document.getElementById('projectLogo').value,
                users: document.getElementById('projectUsers').value,
                servers: document.getElementById('projectServers').value,
                date: document.getElementById('projectDate').value,
                site: document.getElementById('projectSite').value,
                support: document.getElementById('projectSupport').value,
                invite: document.getElementById('projectInvite').value,
                github: document.getElementById('projectGithub').value,
                portfolio: document.getElementById('projectPortfolio').value,
                videos: videos,
                tags: tags
            };

            if (projectId) {
                // Update project
                const response = await fetch(`${API_BASE}/projects/${projectId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(projectData),
                    credentials: 'include'
                });
                if (response.ok) {
                    this.showNotification('Projet mis à jour avec succès!');
                } else {
                    this.showNotification('Erreur lors de la mise à jour', 'error');
                }
            } else {
                // Create project
                const response = await fetch(`${API_BASE}/projects`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(projectData),
                    credentials: 'include'
                });
                if (response.ok) {
                    this.showNotification('Projet créé avec succès!');
                } else {
                    this.showNotification('Erreur lors de la création', 'error');
                }
            }
            await this.loadProjects();
            this.closeProjectModal();
        } catch (error) {
            console.error('Erreur:', error);
            this.showNotification('Erreur: ' + error.message, 'error');
        }
    }

    async deleteProject(projectId) {
        if (confirm('Êtes-vous sûr de vouloir supprimer ce projet?')) {
            try {
                const response = await fetch(`${API_BASE}/projects/${projectId}`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                if (response.ok) {
                    this.showNotification('Projet supprimé!');
                    await this.loadProjects();
                } else {
                    this.showNotification('Erreur lors de la suppression', 'error');
                }
            } catch (error) {
                console.error('Erreur:', error);
                this.showNotification('Erreur serveur', 'error');
            }
        }
    }

    renderProjects() {
        const container = document.getElementById('projectsList');
        container.innerHTML = this.projects.map(project => `
            <div class="item-card">
                <div class="item-info">
                    <h3>${project.name}</h3>
                    <p>${project.role}</p>
                </div>
                <div class="item-actions">
                    <button class="icon-btn" onclick="adminPanel.openProjectModal(${project.id})" title="Éditer">✏️</button>
                    <button class="icon-btn" onclick="adminPanel.deleteProject(${project.id})" title="Supprimer">🗑️</button>
                </div>
            </div>
        `).join('');

        document.getElementById('projectCount').textContent = this.projects.length;
    }

    async openSkillModal(skillId = null) {
        const modal = document.getElementById('skillModal');
        const form = document.getElementById('skillForm');

        if (skillId) {
            const skill = this.skills.find(s => s.id === skillId);
            if (skill) {
                document.getElementById('skillName').value = skill.name;
                document.getElementById('skillLevel').value = skill.level;
                document.getElementById('skillLevelDisplay').textContent = skill.level + '%';
                form.dataset.skillId = skillId;
            }
        } else {
            form.reset();
            document.getElementById('skillLevel').value = 50;
            document.getElementById('skillLevelDisplay').textContent = '50%';
            delete form.dataset.skillId;
        }

        modal.classList.add('active');
    }

    closeSkillModal() {
        document.getElementById('skillModal').classList.remove('active');
    }

    async handleSkillSubmit(e) {
        e.preventDefault();
        const skillId = e.target.dataset.skillId;

        const skillData = {
            name: document.getElementById('skillName').value,
            level: parseInt(document.getElementById('skillLevel').value)
        };

        try {
            if (skillId) {
                // Update skill
                const response = await fetch(`${API_BASE}/skills/${skillId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(skillData),
                    credentials: 'include'
                });
                if (response.ok) {
                    this.showNotification('Compétence mise à jour!');
                } else {
                    this.showNotification('Erreur lors de la mise à jour', 'error');
                }
            } else {
                // Create skill
                const response = await fetch(`${API_BASE}/skills`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(skillData),
                    credentials: 'include'
                });
                if (response.ok) {
                    this.showNotification('Compétence créée!');
                } else {
                    this.showNotification('Erreur lors de la création', 'error');
                }
            }
            await this.loadSkills();
            this.closeSkillModal();
        } catch (error) {
            console.error('Erreur:', error);
            this.showNotification('Erreur serveur', 'error');
        }
    }

    async deleteSkill(skillId) {
        if (confirm('Êtes-vous sûr de vouloir supprimer cette compétence?')) {
            try {
                const response = await fetch(`${API_BASE}/skills/${skillId}`, {
                    method: 'DELETE',
                    credentials: 'include'
                });
                if (response.ok) {
                    this.showNotification('Compétence supprimée!');
                    await this.loadSkills();
                } else {
                    this.showNotification('Erreur lors de la suppression', 'error');
                }
            } catch (error) {
                console.error('Erreur:', error);
                this.showNotification('Erreur serveur', 'error');
            }
        }
    }

    renderSkills() {
        const container = document.getElementById('skillsList');
        container.innerHTML = this.skills.map(skill => `
            <div class="item-card">
                <div class="item-info">
                    <h3>${skill.name}</h3>
                    <p>Niveau: ${skill.level}%</p>
                </div>
                <div class="item-actions">
                    <button class="icon-btn" onclick="adminPanel.openSkillModal(${skill.id})" title="Éditer">✏️</button>
                    <button class="icon-btn" onclick="adminPanel.deleteSkill(${skill.id})" title="Supprimer">🗑️</button>
                </div>
            </div>
        `).join('');

        document.getElementById('skillCount').textContent = this.skills.length;
    }

    updateSkillLevelDisplay(e) {
        document.getElementById('skillLevelDisplay').textContent = e.target.value + '%';
    }

    loadSettings() {
        document.getElementById('settingName').value = this.profile.name || '';
        document.getElementById('settingTitle').value = this.profile.title || '';
        document.getElementById('settingEmail1').value = this.profile.email1 || '';
        document.getElementById('settingEmail2').value = this.profile.email2 || '';
        document.getElementById('settingAvatar').value = this.profile.avatar || '';
        document.getElementById('settingDiscord').value = this.profile.discord || '';
        
        // Load social links
        if (this.profile.social) {
            document.getElementById('settingTwitter').value = this.profile.social.twitter || '';
            document.getElementById('settingGithub').value = this.profile.social.github || '';
            document.getElementById('settingLinkedin').value = this.profile.social.linkedin || '';
            document.getElementById('settingYoutube').value = this.profile.social.youtube || '';
            document.getElementById('settingInstagram').value = this.profile.social.instagram || '';
            document.getElementById('settingTwitch').value = this.profile.social.twitch || '';
            document.getElementById('settingTiktok').value = this.profile.social.tiktok || '';
        }
    }

    async handleSettingsSubmit(e) {
        e.preventDefault();

        const social = {
            twitter: document.getElementById('settingTwitter').value,
            github: document.getElementById('settingGithub').value,
            linkedin: document.getElementById('settingLinkedin').value,
            youtube: document.getElementById('settingYoutube').value,
            instagram: document.getElementById('settingInstagram').value,
            twitch: document.getElementById('settingTwitch').value,
            tiktok: document.getElementById('settingTiktok').value
        };

        const profileData = {
            name: document.getElementById('settingName').value,
            title: document.getElementById('settingTitle').value,
            email1: document.getElementById('settingEmail1').value,
            email2: document.getElementById('settingEmail2').value,
            avatar: document.getElementById('settingAvatar').value,
            discord: document.getElementById('settingDiscord').value,
            social: social
        };

        try {
            const response = await fetch(`${API_BASE}/profile`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(profileData),
                credentials: 'include'
            });

            if (response.ok) {
                this.showNotification('Paramètres enregistrés avec succès!');
                await this.loadProfile();
            } else {
                this.showNotification('Erreur lors de la mise à jour', 'error');
            }
        } catch (error) {
            console.error('Erreur:', error);
            this.showNotification('Erreur serveur', 'error');
        }
    }

    toggleSidebar() {
        document.querySelector('.sidebar').classList.toggle('open');
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        const bgColor = type === 'error' ? '#ef4444' : '#10b981';
        notification.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: ${bgColor};
            color: white;
            padding: 1rem 2rem;
            border-radius: 0.5rem;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            z-index: 2000;
            animation: slideIn 0.3s ease;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    async handlePasswordSubmit(e) {
        e.preventDefault();

        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            this.showNotification('Les mots de passe ne correspondent pas', 'error');
            return;
        }

        if (newPassword.length < 6) {
            this.showNotification('Le mot de passe doit contenir au moins 6 caractères', 'error');
            return;
        }

        try {
            const response = await fetch(`${API_BASE}/auth/change-password`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ currentPassword, newPassword, confirmPassword }),
                credentials: 'include'
            });

            if (response.ok) {
                this.showNotification('Mot de passe changé avec succès!');
                document.getElementById('passwordForm').reset();
            } else {
                const error = await response.json();
                this.showNotification(error.message || 'Erreur lors du changement de mot de passe', 'error');
            }
        } catch (error) {
            console.error('Erreur:', error);
            this.showNotification('Erreur serveur', 'error');
        }
    }
}

// Initialize Admin Panel
const adminPanel = new AdminPanel();
