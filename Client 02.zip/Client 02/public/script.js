// Portfolio Script with API Integration
const API_BASE = 'http://localhost:5000/api';

class Portfolio {
    constructor() {
        this.profile = null;
        this.projects = [];
        this.skills = [];
        this.init();
    }

    async init() {
        await this.loadProfile();
        await this.loadProjects();
        await this.loadSkills();
        this.setupEventListeners();
    }

    async loadProfile() {
        try {
            const response = await fetch(`${API_BASE}/profile`);
            this.profile = await response.json();
            this.renderProfile();
        } catch (error) {
            console.error('Erreur lors du chargement du profil:', error);
        }
    }

    async loadProjects() {
        try {
            const response = await fetch(`${API_BASE}/projects`);
            this.projects = await response.json();
            this.renderProjects();
        } catch (error) {
            console.error('Erreur lors du chargement des projets:', error);
        }
    }

    async loadSkills() {
        try {
            const response = await fetch(`${API_BASE}/skills`);
            this.skills = await response.json();
            this.renderSkills();
        } catch (error) {
            console.error('Erreur lors du chargement des compétences:', error);
        }
    }

    renderProfile() {
        if (!this.profile) return;

        document.getElementById('navName').textContent = this.profile.name;
        document.getElementById('heroName').textContent = this.profile.name;
        document.getElementById('heroTitle').textContent = this.profile.title;
        document.getElementById('heroAvatar').src = this.profile.avatar;
        document.getElementById('email1').textContent = this.profile.email1;
        document.getElementById('email1Link').href = `mailto:${this.profile.email1}`;
        
        // Handle optional email2
        if (this.profile.email2) {
            document.getElementById('email2').textContent = this.profile.email2;
            document.getElementById('email2Link').href = `mailto:${this.profile.email2}`;
            document.getElementById('email2Link').style.display = 'block';
        }
        
        // Handle Discord link
        if (this.profile.discord) {
            document.getElementById('discordLink').href = this.profile.discord;
        }
        
        // Render social links
        this.renderSocialLinks();
    }

    renderSocialLinks() {
        if (!this.profile || !this.profile.social) return;

        const socialContainer = document.getElementById('socialLinks');
        if (!socialContainer) return;

        const socialPlatforms = {
            twitter: 'https://twitter.com/',
            github: 'https://github.com/',
            linkedin: 'https://linkedin.com/in/',
            youtube: 'https://youtube.com/@',
            instagram: 'https://instagram.com/',
            twitch: 'https://twitch.tv/',
            tiktok: 'https://tiktok.com/@'
        };

        const socialIcons = {
            twitter: '𝕏',
            github: '🐙',
            linkedin: '💼',
            youtube: '▶️',
            instagram: '📷',
            twitch: '🎮',
            tiktok: '🎵'
        };

        let socialLinksHTML = '';

        for (const [platform, url] of Object.entries(this.profile.social)) {
            if (url && url.trim()) {
                const fullUrl = url.startsWith('http') ? url : (socialPlatforms[platform] + url);
                socialLinksHTML += `
                    <a href="${fullUrl}" class="social-link" title="${platform}" target="_blank">
                        ${socialIcons[platform] || '🔗'}
                    </a>
                `;
            }
        }

        socialContainer.innerHTML = socialLinksHTML;
    }

    extractYoutubeId(url) {
        if (!url) return null;
        
        const regexps = [
            /^https?:\/\/(?:www\.)?youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
            /^https?:\/\/(?:www\.)?youtu\.be\/([a-zA-Z0-9_-]{11})/,
            /^https?:\/\/(?:www\.)?youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/,
            /^([a-zA-Z0-9_-]{11})$/ // Direct video ID
        ];
        
        for (let regex of regexps) {
            const match = url.match(regex);
            if (match && match[1]) {
                return match[1];
            }
        }
        return null;
    }

    renderProjects() {
        const container = document.getElementById('projectsContainer');
        container.innerHTML = this.projects.map(project => `
            <div class="project-card">
                <div class="project-header">
                    <img src="${project.logo}" alt="${project.name} Logo" class="project-logo">
                    <h3>${project.name}</h3>
                </div>
                <p class="project-role">${project.role}</p>
                ${project.description ? `<p class="project-description">${project.description}</p>` : ''}
                <div class="project-stats">
                    ${project.users ? `
                    <div class="stat">
                        <span class="stat-value">${project.users}</span>
                        <span class="stat-label">Utilisateurs</span>
                    </div>
                    ` : ''}
                    ${project.servers ? `
                    <div class="stat">
                        <span class="stat-value">${project.servers}</span>
                        <span class="stat-label">Serveurs</span>
                    </div>
                    ` : ''}
                </div>
                <p class="project-date">Actualisé le ${new Date(project.date).toLocaleDateString('fr-FR')}</p>
                <div class="project-links">
                    ${project.site ? `<a href="${project.site}" class="link" target="_blank">🌐 Site</a>` : ''}
                    ${project.support ? `<a href="${project.support}" class="link" target="_blank">💬 Support</a>` : ''}
                    ${project.invite ? `<a href="${project.invite}" class="link" target="_blank">🔗 Invitation</a>` : ''}
                    ${project.github ? `<a href="${project.github}" class="link" target="_blank">💻 GitHub</a>` : ''}
                    ${project.portfolio ? `<a href="${project.portfolio}" class="link" target="_blank">🎨 Portfolio</a>` : ''}
                </div>
                ${project.videos && project.videos.length > 0 ? `
                <div class="project-videos">
                    <h4>📹 Vidéos</h4>
                    <div class="videos-grid">
                        ${project.videos.map(video => {
                            const videoId = this.extractYoutubeId(video.url);
                            if (videoId) {
                                return `
                                    <div class="video-embed">
                                        <h5>${video.title}</h5>
                                        <iframe 
                                            width="100%" 
                                            height="315" 
                                            src="https://www.youtube.com/embed/${videoId}" 
                                            title="${video.title}" 
                                            frameborder="0" 
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                                            referrerpolicy="strict-origin-when-cross-origin" 
                                            allowfullscreen>
                                        </iframe>
                                    </div>
                                `;
                            } else {
                                return `
                                    <div class="video-link-fallback">
                                        <a href="${video.url}" target="_blank" class="video-link">
                                            <span>▶️ ${video.title}</span>
                                        </a>
                                    </div>
                                `;
                            }
                        }).join('')}
                    </div>
                </div>
                ` : ''}
                ${project.tags && project.tags.length > 0 ? `
                <div class="project-tags">
                    ${project.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                </div>
                ` : ''}
            </div>
        `).join('');
    }

    renderSkills() {
        const container = document.getElementById('skillsContainer');
        container.innerHTML = this.skills.map(skill => `
            <div class="skill-item">
                <h4>${skill.name}</h4>
                <div class="skill-bar">
                    <div class="skill-progress" style="width: ${skill.level}%"></div>
                </div>
                <span class="skill-percentage">${skill.level}%</span>
            </div>
        `).join('');
    }

    setupEventListeners() {
        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        // Navbar background on scroll
        const navbar = document.querySelector('.navbar');
        window.addEventListener('scroll', () => {
            if (window.scrollY > 50) {
                navbar.style.background = 'rgba(15, 23, 42, 0.98)';
                navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.3)';
            } else {
                navbar.style.background = 'rgba(15, 23, 42, 0.95)';
                navbar.style.boxShadow = 'none';
            }
        });

        // Intersection Observer for animations
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -100px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        document.querySelectorAll('.project-card, .skill-item').forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(element);
        });
    }
}

// Initialize Portfolio
const portfolio = new Portfolio();
